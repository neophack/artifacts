#!/bin/bash

wget https://raw.githubusercontent.com/coin-or/coinbrew/master/coinbrew -O ./coinbrew

